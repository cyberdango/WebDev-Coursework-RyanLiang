#include <iostream>
#include "treasurePath.h"

using namespace std;


int maximumParent(int arr[][COLS], int rNum, int cNum){
    // TODO: Find the maximum value among the parent cells
    //   Parent cells are in row (rNum - 1) at columns: cNum-1, cNum, cNum+1
    //   Be careful with boundary checks (first and last columns)

    return 0;
}


int maximumTreasure(int treasure[][COLS], int collection[][COLS], int rows){
    // TODO: Implement the treasure path algorithm
    //   1. Create a helper array to store accumulated path values
    //   2. Copy the first row from treasure (base case)
    //   3. For each subsequent row, compute the best path value
    //      using maximumParent
    //   4. Find the maximum value in the last row
    //   5. Trace back through the helper array to fill collection
    //      with the cells on the optimal path

    return 0;
}


bool test_treasure_paths(){
    // TODO: Test your algorithm with the test arrays from main.cpp
    //   Expected result: maximum value = 7 * number of rows
    //   Return true if all tests pass

    return false;
}
